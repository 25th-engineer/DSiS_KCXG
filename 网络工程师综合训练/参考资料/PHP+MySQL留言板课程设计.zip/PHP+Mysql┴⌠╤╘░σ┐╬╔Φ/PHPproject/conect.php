﻿<?php  
    define('DB_HOST', 'localhost');  
    define('DB_USER', 'root');  
    define('DB_PWD', 'php1980');  
    define('DB_CHARSET', 'UTF8');  
    define('DB_DBNAME', 'myDemo'); 
?>
